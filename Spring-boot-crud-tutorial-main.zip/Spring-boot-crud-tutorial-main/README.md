# Spring boot tutorial for beginners

Refer to this article: https://deeppatel23.medium.com/crud-operations-in-spring-boot-and-mysql-rest-apis-9ca0c15bdc73

This article covered how to create a RESTful API for CRUD(Create, Retrieve, Update and Delete) operations in Spring Boot with the MySQL database.

